//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "SHDocVw_OCX"
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm2::CppWebBrowser1NavigateComplete2(TObject *Sender,
      LPDISPATCH pDisp, TVariant *URL)
{
Application->MessageBox("Loading complete","",0);        
}
//---------------------------------------------------------------------------

