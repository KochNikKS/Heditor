//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button2Click(TObject *Sender)
{
Form3->Hide();
}
//---------------------------------------------------------------------------



void __fastcall TForm3::Button1Click(TObject *Sender)
{
int Start = 0;int pos =0;
if(RadioButton2->Checked) Start = Form1->RichEdit1->SelStart;

//if (CheckBox3->Checked)TSearchTypes()<<stMatchCase;
pos = Form1->RichEdit1->FindText(Edit1->Text,Start,
Form1->RichEdit1->Text.Length() - Start, TSearchTypes());

Form3->Hide();
if (pos != -1)
{
        if (CheckBox1->Checked)
        {
        Form1->RichEdit1->SetFocus();
        Form1->RichEdit1->SelStart = pos;
        Form1->RichEdit1->SelLength = Edit1->Text.Length();
        Form1->RichEdit1->SelText= Edit2->Text;
        Form1->RichEdit1->SelStart = pos+Edit2->Text.Length();
        }
        else
        {
        Form1->RichEdit1->SetFocus();
        Form1->RichEdit1->SelStart = pos+Edit1->Text.Length();
        }

}
        Form1->Panel1->Visible = true;
}
//---------------------------------------------------------------------------


void __fastcall TForm3::FormShow(TObject *Sender)
{
Form1->Enabled = false;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormHide(TObject *Sender)
{
Form1->Enabled = true;
}
//---------------------------------------------------------------------------

